Exceptions
**********

.. autoapiexception:: pikepdf.PdfError

.. autoapiexception:: pikepdf.PasswordError

.. autoapiexception:: pikepdf.ForeignObjectError

.. autoapiexception:: pikepdf.OutlineStructureError

.. autoapiexception:: pikepdf.UnsupportedImageTypeError

.. autoapiexception:: pikepdf.DataDecodingError

.. autoapiexception:: pikepdf.DeletedObjectError